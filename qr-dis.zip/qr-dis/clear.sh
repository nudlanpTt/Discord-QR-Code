
rm qr.png
rm qr-template/discord_gift.png