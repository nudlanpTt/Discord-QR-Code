
echo "Save the displayed qrcode as 'qr.png' in current folder."

xterm -e firefox --private-window https://discord.com/login

echo "After saving picture hit enter."
read name

python3 app.py
